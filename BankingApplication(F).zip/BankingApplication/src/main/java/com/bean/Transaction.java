package com.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="transactions")
public class Transaction {

    @Id
    private Long transactionId;

    private Long senderAccountNo;
    private Long receiverAccountNo;
    private Double amount;
    private String transactionType;
    private LocalDateTime timeStamp;
    private String status;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name="account_no")
    private Account account;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="customerId")
    private Customer customer;

    public long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }

    public long getSenderAccountNo() {
        return senderAccountNo;
    }

    public void setSenderAccountNo(long senderAccountNo) {
        this.senderAccountNo = senderAccountNo;
    }

    public long getReceiverAccountNo() {
        return receiverAccountNo;
    }

    public void setReceiverAccountNo(long receiverAccountNo) {
        this.receiverAccountNo = receiverAccountNo;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
