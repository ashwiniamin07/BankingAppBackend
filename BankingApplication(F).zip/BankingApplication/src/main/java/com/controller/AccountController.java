package com.controller;

import com.bean.Customer;
import com.bean.Transaction;
import com.dto.CustDto;
import com.service.TransactionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.dto.AccountDTO;
import com.bean.Account;
import com.mapper.AccountMapper;
import com.service.AccountService;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/accounts")
public class AccountController {
    @Autowired
    private AccountService accountService;

    @PostMapping("/create")
    public AccountDTO createAccount(@RequestBody AccountDTO accountDTO) {
        Account account=AccountMapper.toEntity(accountDTO);
        Account saved=accountService.addAccount(account);
        return AccountMapper.toDTO(saved);
    }
    @GetMapping("/{accountNo}")
    public AccountDTO getAccount(@PathVariable Long accountNo) {
        Account account=accountService.getAccountDetailById(accountNo);
        return AccountMapper.toDTO(account);
    }
    @GetMapping("/getall")
    public List<AccountDTO> getAllAccounts(){
        return accountService.getAllAccounts()
                .stream()
                .map(AccountMapper::toDTO)
                .collect(Collectors.toList());
    }

    @PutMapping("/update/{accountNo}")
    public AccountDTO updateAccount(@PathVariable Long accountNo, @RequestBody AccountDTO accountDTO){
        Account account = AccountMapper.toEntity(accountDTO);
        account.setAccountNo(accountNo); // Set accountNo from the path
        Account updated = accountService.updateAccount(account);
        return AccountMapper.toDTO(updated);
    }

    @DeleteMapping("/delete/{accountNo}")
    public void deleteAccount(@PathVariable Long accountNo) {
        accountService.deleteAccount(accountNo);
    }
    @GetMapping("/{accountNo}/balance")
    public Double getBalance(@PathVariable Long accountNo) {
        return accountService.getAccountBalance(accountNo);
    }
    @GetMapping("/{accountNo}/exists")
    public boolean checkExists(@PathVariable Long accountNo) {
        return accountService.verifyAccountExists(accountNo);
    }
    @PutMapping("/{accountNo}/freeze")
    public String freeze(@PathVariable Long accountNo) {
        return accountService.freezeAccount(accountNo);
    }
    @PutMapping("/{accountNo}/unfreeze")
    public String unfreeze(@PathVariable Long accountNo) {
        return accountService.unfreezeAccount(accountNo);
    }

    @GetMapping("/customer/{custId}")
    public List<AccountDTO> getAccountsByCustomerId(@PathVariable Long custId){
        return accountService.getAccountsByCustId(custId).stream().map(AccountMapper::toDTO).collect(Collectors.toList());
    }

    @GetMapping("/{accountId}/holder")
    public CustDto getCustomerDetails(@PathVariable Long accountId) {
        Customer customer = accountService.getCustomerDetails(accountService.getAccountDetailById(accountId));
        return new CustDto(customer.getCustomerId(), customer.getFullName(), customer.getContactNo(),
                customer.getDob(), customer.getLogin().getEmail());
    }

    @GetMapping("/{accountNo}/statement")
        public List<Transaction> getAccountStatement(@PathVariable Long accountNo, @RequestParam("fromDate") String startDate, @RequestParam("toDate") String endDate){
        LocalDate fromDate = LocalDate.parse(startDate);
        LocalDate toDate = LocalDate.parse(endDate);
        return accountService.getAccountStatement(accountNo,fromDate,toDate);
    }




}