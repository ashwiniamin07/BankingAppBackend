package com.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.bean.Address;
import com.bean.Customer;
import com.dto.CustDto;
import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/auth/customer")

public class CustomerController {
	@Autowired
	private CustomerService customerService;

	@PostMapping("/register")
	public ResponseEntity<?> register(@Valid @RequestBody RegisterDto registerDto, BindingResult bindingResult) {
		System.out.println("Received Customer: " + registerDto.getCustomer());
		System.out.println("Received Login: " + registerDto.getLogin());
		System.out.println("Received Address List: " + registerDto.getAddressList());

		if (bindingResult.hasErrors()) {

			return ResponseEntity.badRequest().body(bindingResult.getAllErrors());

		}

		RegRespDto response = customerService.regCustomer(registerDto);

		return ResponseEntity.ok(response);

	}




	@GetMapping("get/customers")

	public List<Customer> getAllCustomers(){

		return customerService.getAllCustomers();

	}

	@GetMapping("getcustomer/{id}")

	public Optional<Customer> getCustomerById(@PathVariable int id) {

		return customerService.getCustById(id);

	}

	@PutMapping("customer/update/{id}")

	public Customer updateCustomerById(@PathVariable int id, @Valid @RequestBody Customer cust){

		return customerService.updateCustomerById(id, cust);

	}

	@DeleteMapping("customer/delete/{id}")

	Customer deleteCustomer(@PathVariable int id) {

		return customerService.deleteCustomer(id);

	}

	@PatchMapping("customer/update-name/{id}")

	public ResponseEntity<?> updateCustomerName(

			@PathVariable int id,

			@RequestBody Map<String, String> updates) {

		String newName = updates.get("fullName");

		if (newName == null || newName.trim().isEmpty()) {

			return ResponseEntity.badRequest().body("Name cannot be empty");

		}

		if (newName.length() < 2) {

			return ResponseEntity

					.badRequest()

					.body("Name must be at least 2 characters long");

		}

		Customer updatedCustomer = customerService.updateCustomerName(id, newName);

		return ResponseEntity.ok(updatedCustomer);

	}

	@PatchMapping("customer/update-address/{id}")

	public ResponseEntity<?> updateCustomerAddress(

			@PathVariable int id,

			@Valid @RequestBody Address address) {

		Customer updatedCustomer = customerService.updateCustAddr(id, address);

		return ResponseEntity.ok(updatedCustomer);

	}

	@GetMapping("getcustomers/name/{name}")

	public List<Customer> getCustByName(@PathVariable String name) {

		return customerService.getCustByName(name);

	}

	@GetMapping("getcustomers/dob/{dob}")

	public List<Customer> getCustByDob(@PathVariable LocalDate dob) {

		return customerService.getCustByDob(dob);

	}

	@PatchMapping("customer/update-dob/{id}")

	public ResponseEntity<?> updateCustomerDob(

			@PathVariable int id,

			@RequestBody Map<String, String> updates) {

		String newDobString = updates.get("dob");

		if (newDobString == null || newDobString.trim().isEmpty()) {

			return ResponseEntity.badRequest().body("Date of Birth cannot be empty");

		}

		LocalDate newDob;

		try {

			newDob = LocalDate.parse(newDobString);

		} catch (Exception e) {

			return ResponseEntity.badRequest().body("Invalid Date format. Please use YYYY-MM-DD format.");

		}

		if (newDob.isAfter(LocalDate.now())) {

			return ResponseEntity.badRequest().body("Date of Birth cannot be a future date");

		}

		Customer updatedCustomer = customerService.updateCustDob(id, newDob);

		return ResponseEntity.ok(updatedCustomer);

	}

	@GetMapping("/customerdto/{id}")

	public CustDto getCustDtoById(@PathVariable int id) {

		return customerService.getCustDtoById(id);

	}

	@PutMapping("/customer/update-dto/{id}")

	public ResponseEntity<?> updateCustomerDtoById(

			@PathVariable int id,

			@Valid @RequestBody CustDto custDto) {

		CustDto updated = customerService.updateCustDtoById(id, custDto);

		return ResponseEntity.ok(updated);

	}

	@GetMapping("/customer/by-email/{email}")

	public ResponseEntity<?> getCustomerByEmail(@PathVariable String email) {

		Customer customer = customerService.getCustByEmail(email);

		return ResponseEntity.ok(customer);

	}

	@PostMapping("/add")

	public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {

		Customer savedCustomer = customerService.addCustomer(customer);

		return ResponseEntity.status(HttpStatus.CREATED).body(savedCustomer);

	}


}

