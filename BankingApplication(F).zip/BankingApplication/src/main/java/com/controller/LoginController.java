package com.controller;

import com.bean.Customer;
import com.dto.LoginDto;
import com.service.LoginServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/auth")
public class LoginController {
	@Autowired
	private LoginServiceImpl loginService;

	@PostMapping("/login")
	public ResponseEntity<?> login(@Valid @RequestBody LoginDto loginDto){

		// Perform login logic, and if successful:
		Customer customer = loginService.loginAndFetchCustomer(loginDto);
		if (customer != null) {
			// Return the customer data along with a success message
			return ResponseEntity.ok(customer);

		} else {
			// If login fails, return an unauthorized error
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ResponseMessage("Invalid email, password, or role"));

		}

	}

	// ResponseMessage class to structure the response
	public static class ResponseMessage {
		private String message;
		public ResponseMessage(String message) {
			this.message = message;

		}

		public String getMessage() {
			return message;

		}

		public void setMessage(String message) {
			this.message = message;

		}

	}

}

