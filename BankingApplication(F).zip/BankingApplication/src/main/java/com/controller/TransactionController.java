package com.controller;

import com.dto.TransactionDTO;
import com.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/accounts")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;

    @PostMapping("/{accountId}/deposit")
    public ResponseEntity<String> deposit(@PathVariable Long accountId, @RequestBody Double amount){
        return ResponseEntity.ok(transactionService.deposit(accountId,amount));
    }

    @PostMapping("/{accountId}/withdraw")
    public ResponseEntity<String> withdraw(@PathVariable Long accountId, @RequestBody Double amount){
        return ResponseEntity.ok(transactionService.withdraw(accountId,amount));
    }

    @PostMapping("/{from}/transfer/{to}")
    public ResponseEntity<String> transferAmount(@PathVariable Long from,@PathVariable Long to,@RequestBody Double amount){
        return ResponseEntity.ok(transactionService.transferAmount(from,to,amount));
    }

    @GetMapping("/{accountId}/transactions")
    public ResponseEntity<List<TransactionDTO>> getAllTransactions(@PathVariable Long accountId){
        List<TransactionDTO> response = transactionService.getAllTransactions(accountId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{accountId}/transactions/{startDate}/{endDate}")
    public ResponseEntity<List<TransactionDTO>> getTransactionsBetweenDates(@PathVariable Long accountId, @PathVariable LocalDate startDate, @PathVariable LocalDate endDate){
        List<TransactionDTO> response = transactionService.getTransactionsBetweenDates(accountId,startDate,endDate);
        return ResponseEntity.ok(response);
    }

}
