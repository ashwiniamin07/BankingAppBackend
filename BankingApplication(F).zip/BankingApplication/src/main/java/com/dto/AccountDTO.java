package com.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public class AccountDTO {
    private Long accountNo;
    private String accountType;
    private Double balance;

    private LocalDate createdAt;
    private Boolean isFrozen;
    @NotNull(message = "Customer ID is required")
    private Long customerId;
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    public Double getBalance() {
        return balance;
    }
    public void setBalance(Double balance) {
        this.balance = balance;
    }
    public LocalDate getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }
    public Boolean getIsFrozen() {
        return isFrozen;
    }
    public void setIsFrozen(Boolean isFrozen) {
        this.isFrozen = isFrozen;
    }
    public Long getCustomerId() {
        return customerId;
    }
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    public Long getAccountNo() {
        return accountNo;
    }
    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }


}
