package com.dto;

import java.time.LocalDate;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CustDto {
	    private Long customerId;

	    @NotBlank(message="Name can't be empty")
	    @Size(min=2, message="Name must be atleast greater than 2 characters")
	    @Valid
	    private String fullName;

	    @NotBlank(message="Contact number can't be empty")
	    @Pattern(regexp="^[6-9]\\d{9}$", message="Contact number must be 10 digit number")
	    @Valid
	    private String contactNo;

	    @NotNull(message="Date of birth can't be empty")
	    @Past(message="Date of Birth must be past date")
	    @Valid
	    private LocalDate dob;

	    @NotBlank(message="Email can't be empty")
	    @Email(message="Incorrect email format")
	    @Valid
	    private String email;

	    public CustDto(long customerId, String fullName, String contactNo, LocalDate dob, String email) {
	        this.customerId = customerId;
	        this.fullName = fullName;
	        this.contactNo = contactNo;
	        this.dob = dob;
	        this.email = email;
	    }

	    public long getCustomerId() {
	        return customerId;
	    }

	    public void setCustomerId(long customerId) {
	        this.customerId = customerId;
	    }

	    public String getFullName() {
	        return fullName;
	    }

	    public void setFullName(String fullName) {
	        this.fullName = fullName;
	    }

	    public String getContactNo() {
	        return contactNo;
	    }

	    public void setContactNo(String contactNo) {
	        this.contactNo = contactNo;
	    }

	    public LocalDate getDob() {
	        return dob;
	    }

	    public void setDob(LocalDate dob) {
	        this.dob = dob;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }
}

