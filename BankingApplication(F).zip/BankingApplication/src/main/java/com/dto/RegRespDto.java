package com.dto;

public class RegRespDto {
	private String message;
	private Long customerId;
	public RegRespDto(String message, Long customerId) {
		this.message = message;
		this.customerId = customerId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	
}
