package com.dto;

import java.time.LocalDate;
import java.util.List;


import com.bean.Address;
import com.bean.Customer;
import com.bean.Login;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class RegisterDto {
	
	
	@NotNull(message="Customer details are required")
	@Valid
	private Customer customer;
	
	@NotNull(message="Login details are required")
	@Valid
	private Login login;
	
	@NotEmpty
	@Valid
	private List<Address> addressList;

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	
	
	
	
	
}
