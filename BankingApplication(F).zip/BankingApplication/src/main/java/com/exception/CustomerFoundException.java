package com.exception;

public class CustomerFoundException extends RuntimeException{
	public CustomerFoundException(String message) {
		super(message);
	}
}
