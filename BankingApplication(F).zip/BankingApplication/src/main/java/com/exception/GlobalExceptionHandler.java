package com.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.format.DateTimeParseException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
	    StringBuilder errorMessage = new StringBuilder("Validation failed: ");
	    ex.getBindingResult().getFieldErrors().forEach(error -> {
	        String field = error.getField();
	        String defaultMessage = error.getDefaultMessage();
	        errorMessage.append("Field '" + field + "' is invalid: " + defaultMessage + ". ");
	    });
	    return new ResponseEntity<>(errorMessage.toString(), HttpStatus.BAD_REQUEST);
	}

	
	@ExceptionHandler(CustomerFoundException.class)
	public ResponseEntity<String> handleCustomerFoundException(CustomerFoundException ex){
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(com.exception.NoCustomerFoundException.class)
	public ResponseEntity<String> handleNoCustomerFoundException(com.exception.NoCustomerFoundException ex) {
	    return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<String> handleCustomerNotFound(CustomerNotFoundException ex) {
	    return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(AccountNotFoundException.class)
	public  ResponseEntity<String> handleAccountNotFound(AccountNotFoundException ex){
		return ResponseEntity.badRequest().body("Account Not Found: "+ex.getMessage());
	}

	@ExceptionHandler(InvalidAmountException.class)
	public  ResponseEntity<String> handleInvalidAmount(InvalidAmountException ex){
		return ResponseEntity.badRequest().body("Transaction Failed: "+ex.getMessage());
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public  ResponseEntity<String> handleIllegalArgument(IllegalArgumentException ex){
		return ResponseEntity.badRequest().body(ex.getMessage());
	}

	@ExceptionHandler(DateTimeParseException.class)
	public ResponseEntity<String> handleDateTimeParseException(DateTimeParseException ex){
		return ResponseEntity.badRequest().body("Invalid date. Please use format yyyy-mm-dd");
	}


}
