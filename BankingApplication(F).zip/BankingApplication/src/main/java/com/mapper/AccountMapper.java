package com.mapper;

import com.dto.AccountDTO;
import com.bean.Account;
import com.bean.Customer;

public class AccountMapper {
    public static AccountDTO toDTO(Account account) {
        AccountDTO dto=new AccountDTO();
        dto.setAccountNo(account.getAccountNo());
        dto.setAccountType(account.getAccountType());
        dto.setBalance(account.getBalance());
        dto.setIsFrozen(account.getIsFrozen());
        dto.setCreatedAt(account.getCreatedAt());
        if(account.getCustomer()!=null){
            dto.setCustomerId(account.getCustomer().getCustomerId());
        }
        return dto;
    }
    public static Account toEntity(AccountDTO dto) {
        Account account = new Account();
        account.setAccountNo(dto.getAccountNo());
        account.setAccountType(dto.getAccountType());
        account.setBalance(dto.getBalance());
        account.setIsFrozen(dto.getIsFrozen());
        account.setCreatedAt(dto.getCreatedAt());

        if (dto.getCustomerId() != null) {
            Customer customer = new Customer();
            customer.setCustomerId(dto.getCustomerId());
            account.setCustomer(customer); // Set the customer
            System.out.println("Customer set in Account: " + customer.getCustomerId());
        } else {
            System.out.println("Customer ID is null in DTO");
        }

        return account;
    }
}