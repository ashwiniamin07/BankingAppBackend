package com.mapper;

import com.bean.Transaction;
import com.dto.TransactionDTO;

public class TransactionMapper {
    public static TransactionDTO toDTO(Transaction transaction) {
        TransactionDTO tdto = new TransactionDTO();
        tdto.setTransactionId(transaction.getTransactionId());
        tdto.setSenderAccountNo(transaction.getSenderAccountNo());
        tdto.setReceiverAccountNo(transaction.getReceiverAccountNo());
        if(transaction.getCustomer()!=null)
            tdto.setCustomerId(transaction.getCustomer().getCustomerId());
        tdto.setAmount(transaction.getAmount());
        tdto.setTransactionType(transaction.getTransactionType());
        tdto.setTimeStamp(transaction.getTimeStamp());
        tdto.setStatus(transaction.getStatus());
        return tdto;
    }

    public static Transaction toEntity(TransactionDTO tdto){
        Transaction transaction = new Transaction();
        transaction.setTransactionId(tdto.getTransactionId());
        transaction.setSenderAccountNo(tdto.getSenderAccountNo());
        transaction.setReceiverAccountNo(tdto.getReceiverAccountNo());
        transaction.setAmount(tdto.getAmount());
        transaction.setTransactionType(tdto.getTransactionType());
        transaction.setTimeStamp(tdto.getTimeStamp());
        transaction.setStatus(tdto.getStatus());
        return transaction;
    }

}
