package com.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.bean.Account;
import com.bean.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface AccountRepository extends JpaRepository<Account,Long>{
    List<Account> findByCustomerCustomerId(Long customerId);
    boolean existsByAccountNo(Long accountNo);

    @Query("SELECT t FROM Transaction t WHERE (t.senderAccountNo = :accountNo OR t.receiverAccountNo = :accountNo) AND t.timeStamp BETWEEN :start AND :end")
    List<Transaction> getStatementsBetweenDates(@Param("accountNo") Long accountNo, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

}