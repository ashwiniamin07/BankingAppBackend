package com.repository;

import com.bean.Transaction;
import org.springframework.cglib.core.Local;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    //native query
    @Query(value = "select * from transactions t where t.sender_account_no = :accountNo or t.receiver_account_no = :accountNo",nativeQuery = true)
    List<Transaction> getTransactionsByAccountNo(Long accountNo);

    //jpql query
    @Query("SELECT t FROM Transaction t WHERE (t.senderAccountNo = :accountNo OR t.receiverAccountNo = :accountNo) AND t.timeStamp BETWEEN :start AND :end")
    List<Transaction> getTransactionsBetweenDates(@Param("accountNo") Long accountNo, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}
