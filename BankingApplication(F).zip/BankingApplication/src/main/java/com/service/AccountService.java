package com.service;

import com.bean.Account;
import com.bean.Customer;
import com.bean.Transaction;

import java.time.LocalDate;
import java.util.List;



public interface AccountService {
    Account addAccount(Account account);
    Account getAccountDetailById(Long accountNo);
    List<Account> getAllAccounts();
    List<Account> getAccountsByCustId(Long customerId);
    Account updateAccount(Account account);
    void deleteAccount(Long accountNo);
    Double getAccountBalance(Long accountNo);
    boolean verifyAccountExists(Long accountNo);
    String freezeAccount(Long accountNo);
    String unfreezeAccount(Long accountNo);
    Customer getCustomerDetails(Account account);
    List<Transaction> getAccountStatement(Long accountNo, LocalDate fromDate, LocalDate toDate);
}