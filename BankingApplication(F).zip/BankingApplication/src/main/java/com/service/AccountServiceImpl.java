package com.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.exception.AccountNotFoundException;
import com.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Account;
import com.bean.Customer;
import com.bean.Transaction;
import com.repository.AccountRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Account addAccount(Account account) {
        System.out.println("Received Account entity: " + account);
        if (account.getCustomer() == null) {
            throw new IllegalArgumentException("Customer object is missing in Account.");
        }
        if (account.getCustomer().getCustomerId() == null) {
            throw new IllegalArgumentException("Customer ID is missing in the Customer object.");
        }
        if(account.getBalance() == null || account.getBalance()<0){
            throw new IllegalArgumentException("Initial deposit must be non-negative");
        }

        System.out.println("Fetching Customer with ID: " + account.getCustomer().getCustomerId());
        Customer customer = customerRepository.findById(account.getCustomer().getCustomerId())
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with id: " + account.getCustomer().getCustomerId()));
        System.out.println("Fetched Customer: " + customer);

        account.setCustomer(customer);
        account.setCreatedAt(LocalDate.now());
        account.setIsFrozen(false);
        return accountRepository.save(account);
    }

    @Override
    public Account getAccountDetailById(Long accountNo) {
        return accountRepository.findById(accountNo)
                .orElseThrow(() -> new EntityNotFoundException("Account not found with accountNo: "+accountNo));
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

	@Override
	public List<Account> getAccountsByCustId(Long customerId) {
		return accountRepository.findByCustomerCustomerId(customerId);
	}

    @Override
    public Account updateAccount(Account updatedAccount) {
        Account existing=getAccountDetailById(updatedAccount.getAccountNo());
        existing.setAccountType(updatedAccount.getAccountType());
        existing.setBalance(updatedAccount.getBalance());
        return accountRepository.save(existing);
    }

    @Override
    public void deleteAccount(Long accountNo) {
        Account account = getAccountDetailById(accountNo);
        if(!accountRepository.existsById(accountNo)) {
            throw new EntityNotFoundException("Account Not Found with accountNo: "+accountNo);
        }
        if(account.getIsFrozen()){
            throw new IllegalStateException("Cannot delete a frozen account");
        }
        accountRepository.deleteById(accountNo);

    }

    @Override
    public Double getAccountBalance(Long accountNo) {
        Account account=getAccountDetailById(accountNo);
        return account.getBalance();
    }

    @Override
    public boolean verifyAccountExists(Long accountNo) {
        return accountRepository.existsById(accountNo);
    }

    @Override
    public String freezeAccount(Long accountNo) {
        Account account=getAccountDetailById(accountNo);
        if(account.getIsFrozen()){
            return "Account " +accountNo+ "has already been frozen.";
        }
        account.setIsFrozen(true);
        accountRepository.save(account);
        return "Account " +accountNo+" has been frozen";
    }

    @Override
    public String unfreezeAccount(Long accountNo) {
        Account account=getAccountDetailById(accountNo);
        if(!account.getIsFrozen()){
            return "Account" +accountNo+ "is already unfrozen.";
        }
        account.setIsFrozen(false);
        accountRepository.save(account);
        return "Account " + accountNo + " has been unfrozen.";
    }

    @Override
    public Customer getCustomerDetails(Account account) {
        if (account == null || account.getAccountNo() == null) {
            throw new IllegalArgumentException("Account object or Account ID is missing.");
        }
        return account.getCustomer(); // Return the associated Customer
    }

	@Override
	public List<Transaction> getAccountStatement(Long accountNo, LocalDate startDate, LocalDate endDate) {
        Optional<Account> optionalAccount = accountRepository.findById(accountNo);
        if(optionalAccount.isEmpty()){
            throw new AccountNotFoundException("Invalid Account Number");
        }
        Account account = optionalAccount.get();
        LocalDate accountCreationDate = account.getCreatedAt();
        if(startDate.isBefore(accountCreationDate)){
            throw new IllegalArgumentException("Start Date cannot be before Account creation date");
        }
        if(startDate.isAfter(endDate)){
            throw new IllegalArgumentException("Start Date cannot be after end Date");
        }
        if(endDate.isAfter(LocalDate.now())){
            throw new IllegalArgumentException("End Date cannot be in the future");
        }
        if(endDate.isBefore(startDate)){
            throw new IllegalArgumentException("End Date cannot be before start date");
        }
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23,59,59);
        List<Transaction> transactions = accountRepository.getStatementsBetweenDates(accountNo,startDateTime,endDateTime);
		return account.getTransactions().stream()
				.filter(txn -> {
					LocalDate txnDate=txn.getTimeStamp().toLocalDate();
					return !txnDate.isBefore(startDate) && !txnDate.isAfter(endDate);
				})
				.collect(Collectors.toList());
	}

}
