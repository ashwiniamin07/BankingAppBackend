package com.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.bean.Address;
import com.bean.Customer;
import com.dto.CustDto;
import com.exception.CustomerNotFoundException;
import com.dto.RegRespDto;
import com.dto.RegisterDto;

public interface CustomerService {
	RegRespDto regCustomer(RegisterDto dto);
	List<Customer> getAllCustomers();
	Optional<Customer> getCustById(int custId) throws CustomerNotFoundException;
	Customer updateCustomerById(int custId, Customer cust);
	Customer deleteCustomer(int custId) throws CustomerNotFoundException;
	Customer updateCustomerName(int custId, String newName);
	Customer updateCustAddr(int custId, Address addr);
	List<Customer> getCustByName(String custName);
	List<Customer> getCustByDob(LocalDate dob);
	Customer updateCustDob(int custId, LocalDate newDob);
	CustDto getCustDtoById(int custId) throws CustomerNotFoundException;
	CustDto updateCustDtoById(int custId, CustDto custDto) throws CustomerNotFoundException;
	Customer getCustByEmail(String email);
	Customer addCustomer(Customer customer);
}
