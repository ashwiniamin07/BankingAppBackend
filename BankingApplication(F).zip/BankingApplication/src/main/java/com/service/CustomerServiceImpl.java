package com.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.bean.Address;
import com.bean.Customer;
import com.bean.Login;
import com.dto.CustDto;
import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.exception.CustomerFoundException;
import com.exception.CustomerNotFoundException;
import com.exception.NoCustomerFoundException;
import com.repository.AddressRepository;
import com.repository.CustomerRepository;
import com.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;


import jakarta.transaction.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private LoginRepository loginRepo;
	@Autowired
	private AddressRepository addressRepo;
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public RegRespDto regCustomer(RegisterDto dto){
		Optional<Login> loginOptional = loginRepo.findByEmail(dto.getLogin().getEmail());
		if (loginOptional.isPresent()) {
			System.out.println("Customer already exists with email: " + dto.getLogin().getEmail());  // Debug log
			throw new CustomerFoundException("Customer already exists with email: " + dto.getLogin().getEmail());
		}
		Customer customer=dto.getCustomer();
		Login login=dto.getLogin();
		customer.setLogin(login);
		login.setCustomer(customer);

		List<Address> addresses=dto.getAddressList();
		for(Address addr: addresses) {
			addr.setCustomer(customer);
		}
		customer.setAddress(addresses);
		Customer saved=customerRepo.save(customer);
		return new RegRespDto("Registration successful", saved.getCustomerId());
	}
	public List<Customer> getAllCustomers(){
		List<Customer> customers=customerRepo.findAll();
		if(customers.isEmpty()) {
			throw new NoCustomerFoundException("No customers found");
		}
		return customers;
	}
	public Optional<Customer> getCustById(int custId) throws CustomerNotFoundException {
		Optional<Customer> customer=customerRepo.findById((long) custId);
		if(customer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID "+custId+ " doesn't exist.");
		}
		return customer;
	}

	@Transactional
	public Customer updateCustomerById(int custId, Customer cust) {
		Optional<Customer> customerOptional = customerRepo.findById((long) custId);

		if (customerOptional.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}

		Customer existingCust = customerOptional.get();


		existingCust.setFullName(cust.getFullName());
		existingCust.setContactNo(cust.getContactNo());
		existingCust.setDob(cust.getDob());


		if (cust.getLogin() != null) {
			Login existingLogin = existingCust.getLogin();
			existingLogin.setEmail(cust.getLogin().getEmail());
			existingLogin.setPassword(cust.getLogin().getPassword());
			existingLogin.setRole(cust.getLogin().getRole());
		}


		if (cust.getAddress() != null) {
			List<Address> existingAddresses = existingCust.getAddress();
			for (int i = 0; i < existingAddresses.size(); i++) {
				Address existingAddress = existingAddresses.get(i);
				Address newAddress = cust.getAddress().get(i);
				existingAddress.setdNo(newAddress.getdNo());
				existingAddress.setStreetName(newAddress.getStreetName());
				existingAddress.setCity(newAddress.getCity());
				existingAddress.setState(newAddress.getState());
				existingAddress.setPincode(newAddress.getPincode());
			}
		}

		return customerRepo.save(existingCust);
	}


	@Transactional
	@Override
	public Customer deleteCustomer(int custId) throws CustomerNotFoundException {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);
		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}

		Customer customerToDelete = optionalCustomer.get();
		customerRepo.delete(customerToDelete);
		return customerToDelete;
	}
	public Customer updateCustomerName(int custId, String newName) {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);
		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}
		Customer customer=optionalCustomer.get();
		customer.setFullName(newName);
		return customerRepo.save(customer);
	}
	@Override
	@Transactional
	public Customer updateCustAddr(int custId, Address newAddress) {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);
		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}

		Customer customer = optionalCustomer.get();

		List<Address> customerAddresses = customer.getAddress();
		Address addressToUpdate = customerAddresses.get(0);
		addressToUpdate.setdNo(newAddress.getdNo());
		addressToUpdate.setStreetName(newAddress.getStreetName());
		addressToUpdate.setCity(newAddress.getCity());
		addressToUpdate.setState(newAddress.getState());
		addressToUpdate.setPincode(newAddress.getPincode());

		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> getCustByName(String custName) {
		List<Customer> customers = customerRepo.findByFullNameIgnoreCase(custName);
		if (customers.isEmpty()) {
			throw new CustomerNotFoundException("No customers found with the name: " + custName);
		}
		return customers;
	}
	@Override
	public List<Customer> getCustByDob(LocalDate dob){
		List<Customer> customers = customerRepo.findByDob(dob);
		if (customers.isEmpty()) {
			throw new CustomerNotFoundException("No customers found with the date of birth: " + dob);
		}
		return customers;
	}
	@Override
	public Customer updateCustDob(int custId, LocalDate date) {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);
		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}
		Customer customer=optionalCustomer.get();
		customer.setDob(date);
		return customerRepo.save(customer);
	}
	public CustDto getCustDtoById(int custId) throws CustomerNotFoundException {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);

		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}

		Customer customer = optionalCustomer.get();
		CustDto custDto = new CustDto(
				customer.getCustomerId(),
				customer.getFullName(),
				customer.getContactNo(),
				customer.getDob(),
				customer.getLogin().getEmail()
		);

		return custDto;
	}
	@Override
	@Transactional
	public CustDto updateCustDtoById(int custId, CustDto custDto) throws CustomerNotFoundException {
		Optional<Customer> optionalCustomer = customerRepo.findById((long) custId);

		if (optionalCustomer.isEmpty()) {
			throw new CustomerNotFoundException("Customer ID " + custId + " doesn't exist.");
		}

		Customer customer = optionalCustomer.get();

		customer.setFullName(custDto.getFullName());
		customer.setContactNo(custDto.getContactNo());
		customer.setDob(custDto.getDob());

		if (customer.getLogin() != null && custDto.getEmail() != null) {
			customer.getLogin().setEmail(custDto.getEmail());
		}

		Customer updated = customerRepo.save(customer);

		return new CustDto(
				updated.getCustomerId(),
				updated.getFullName(),
				updated.getContactNo(),
				updated.getDob(),
				updated.getLogin() != null ? updated.getLogin().getEmail() : null
		);
	}
	@Override
	public Customer getCustByEmail(String email) throws CustomerNotFoundException {
		Optional<Login> loginOptional = loginRepo.findByEmail(email);

		if (loginOptional.isEmpty()) {
			throw new CustomerNotFoundException("Customer with email " + email + " not found.");
		}

		return loginOptional.get().getCustomer();
	}

	@Override
	@Transactional
	public Customer addCustomer(Customer customer) {
		if (loginRepo.findByEmail(customer.getLogin().getEmail()).isPresent()) {
			throw new CustomerFoundException("Email already exists");
		}

		// Ensure login is saved first
		Login login = customer.getLogin();
		login = loginRepo.save(login);
		customer.setLogin(login);

		// Ensure address list is never null
		List<Address> addresses = customer.getAddress();
		if (addresses == null) {
			addresses = new ArrayList<>();
		}

		for (Address address : addresses) {
			address.setCustomer(customer); // Setup bi-directional relationship
		}

		customer.setAddress(addresses); // Set updated addresses

		return customerRepo.save(customer);
	}


}