package com.service;

import com.bean.Customer;
import com.dto.LoginDto;

public interface LoginService {
//	public boolean login(LoginDto loginDto);
	public Customer loginAndFetchCustomer(LoginDto loginDto);
}
