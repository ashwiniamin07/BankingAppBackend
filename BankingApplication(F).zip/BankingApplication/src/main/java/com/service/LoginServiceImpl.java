package com.service;

import java.util.Optional;

import com.bean.Customer;
import com.bean.Login;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.dto.LoginDto;


import com.repository.CustomerRepository;

import com.repository.LoginRepository;

import com.service.LoginService;

@Service

public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private CustomerRepository customerRepository;

	public Customer loginAndFetchCustomer(LoginDto loginDto) {
		// Fetch the login object using the provided email
		Optional<Login> loginOptional = loginRepository.findByEmail(loginDto.getEmail());
		if (loginOptional.isPresent()) {
			// Extract the Login object from the Optional
			Login login = loginOptional.get();
			// Check if password matches and role is correct (case-insensitive role comparison)
			if (login.getPassword().equals(loginDto.getPassword()) &&
					login.getRole().equalsIgnoreCase(loginDto.getRole())) {
				// If login is successful, fetch the associated customer
				return customerRepository.findById(login.getCustomer().getCustomerId()).orElse(null);
			}
		}
		// Return null if login fails
		return null;
	}
}

