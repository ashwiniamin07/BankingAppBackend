package com.service;

import com.bean.Transaction;
import com.dto.TransactionDTO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionService {
    public String deposit(long accountNo, Double amount);
    public String withdraw(long accountNo, Double amount);
    public String transferAmount(long sourceAccountNo,long targetAccountNo,Double amount);
    public List<TransactionDTO> getAllTransactions(long accountNo);
    public List<TransactionDTO> getTransactionsBetweenDates(long accountNo, LocalDate startDate, LocalDate endDate);


}
