package com.service;

import com.bean.Account;
import com.bean.Transaction;
import com.dto.TransactionDTO;
import com.exception.AccountNotFoundException;
import com.exception.InvalidAmountException;
import com.mapper.TransactionMapper;
import com.repository.AccountRepository;
import com.repository.TransactionRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TransactionServiceImpl implements TransactionService{

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountRepository accountRepository;

    private Long generateTransactionId(){
        long min = 100000000000L;
        long max = 999999999999L;
        return min + (long)(Math.random()*(max-min));
    }

    private void validateAmount(Double amount){
        if(amount == null || amount<=0){
            throw new InvalidAmountException("Invalid amount");
        }
    }

    @Override
    @Transactional
    public String deposit(long accountNo, Double amount) {
        validateAmount(amount);
        Optional<Account> optionalAccount = accountRepository.findById(accountNo);
        Transaction transaction = new Transaction();
        transaction.setTransactionId(generateTransactionId());
        transaction.setSenderAccountNo(0L);
        transaction.setReceiverAccountNo(accountNo);
        transaction.setAmount(amount);
        transaction.setTransactionType("Deposit");
        transaction.setTimeStamp(LocalDateTime.now());

        //checking if the account is present or not
        if(optionalAccount.isPresent()){
            Account account = optionalAccount.get();

            //if account is frozen or not
            if(account.getIsFrozen()){
                transaction.setStatus("Failed");
                transaction.setCustomer(account.getCustomer());
                transactionRepository.save(transaction);
                return "Deposit Failed: Account is Frozen";
            }
            account.setBalance(account.getBalance() + amount); //logic
            accountRepository.save(account);
            transaction.setStatus("Success");
            transaction.setCustomer(account.getCustomer());
            transactionRepository.save(transaction);
            return "Deposit successful.";
        } else{
            throw new AccountNotFoundException("Invalid Account Number");
        }
    }

    @Override
    @Transactional
    public String withdraw(long accountNo, Double amount) {
        validateAmount(amount);
        Optional<Account> optionalAccount = accountRepository.findById(accountNo);
        Transaction transaction = new Transaction();
        transaction.setTransactionId(generateTransactionId());
        transaction.setReceiverAccountNo(0L);
        transaction.setSenderAccountNo(accountNo);
        transaction.setAmount(amount);
        transaction.setTransactionType("Withdraw");
        transaction.setTimeStamp(LocalDateTime.now());

        //checking if account is present or not
        if(optionalAccount.isPresent()){
            Account account = optionalAccount.get();

            //if account is frozen or not
            if(account.getIsFrozen()){
                transaction.setStatus("Failed");
                transaction.setCustomer(account.getCustomer());
                transactionRepository.save(transaction);
                return "Withdraw Failed: Account is Frozen";
            }

            //checking if account has more balance than the required amount to be withdrawn
            if(account.getBalance()<amount){
                transaction.setStatus("Failed");
                transaction.setCustomer(account.getCustomer());
                transactionRepository.save(transaction);
                return "Withdraw Failed: Insufficient balance";
            }

            account.setBalance(account.getBalance() - amount);
            accountRepository.save(account);
            transaction.setStatus("Success");
            transaction.setCustomer(account.getCustomer());
            transactionRepository.save(transaction);
            return "withdraw successful.";
        }
        throw new AccountNotFoundException("Invalid Account Number");
    }

    @Override
    @Transactional
    public String transferAmount(long sourceAccountNo, long targetAccountNo, Double amount) {
        validateAmount(amount);
        Transaction transaction = new Transaction();
        transaction.setTransactionId(generateTransactionId());
        transaction.setSenderAccountNo(sourceAccountNo);
        transaction.setReceiverAccountNo(targetAccountNo);
        transaction.setAmount(amount);
        transaction.setTransactionType("Transfer");
        transaction.setTimeStamp(LocalDateTime.now());

        //checking if the amount is transferred to same account no.
        if(Objects.equals(sourceAccountNo, targetAccountNo)){
            transaction.setStatus("Failed");
            transactionRepository.save(transaction);
            return "Transfer Failed: Amount cannot be transferred to same account";
        }
        Optional<Account> sourceOptAccount = accountRepository.findById(sourceAccountNo);
        Optional<Account> targetOptAccount = accountRepository.findById(targetAccountNo);

        boolean sourceValid = sourceOptAccount.isPresent();
        boolean targetValid = targetOptAccount.isPresent();

        if(!sourceValid || !targetValid){
            transaction.setStatus("Failed");
            if(!sourceValid && !targetValid){
                throw new AccountNotFoundException("source and target account are invalid");
            } else if(!sourceValid){
                throw new AccountNotFoundException("source account is invalid");
            } else{
                throw new AccountNotFoundException("target account is invalid");
            }
        }
        Account source = sourceOptAccount.get();
        Account target = targetOptAccount.get();

        boolean sourceFrozen = source.getIsFrozen();
        boolean targetFrozen = target.getIsFrozen();

        if(sourceFrozen || targetFrozen){
            transaction.setCustomer(source.getCustomer());
            transaction.setStatus("Failed");
            transactionRepository.save(transaction);
            if(sourceFrozen && targetFrozen){
                return "Transfer Failed: Both source and target account are frozen";
            } else if(sourceFrozen){
                return "Transfer Failed: Source Account is frozen";
            } else{
                return "Transfer Failed: Target Account is frozen";
            }
        }
            //if account is frozen or not
        if(source.getIsFrozen() || target.getIsFrozen()){
            transaction.setCustomer(source.getCustomer());
            transaction.setStatus("Failed");
                transactionRepository.save(transaction);
                return "Transfer Failed: Source Account or Target account or both are Frozen";
        }

            //checking if account has more balance than the required amount to be withdrawn
            if(source.getBalance()<amount){
                transaction.setCustomer(source.getCustomer());
                transaction.setStatus("Failed");
                transactionRepository.save(transaction);
                return "Transfer Failed: Insufficient balance";
            }

            source.setBalance(source.getBalance() + amount); //logic
            target.setBalance(target.getBalance() - amount); //logic
            accountRepository.save(source);
            accountRepository.save(target);
            transaction.setStatus("Success");
            transaction.setCustomer(source.getCustomer());
            transactionRepository.save(transaction);
            return "Amount Transferred successfully.";
    }


    @Override
    public List<TransactionDTO> getAllTransactions(long accountNo) {
        Optional<Account> optionalAccount = accountRepository.findById(accountNo);
        if(optionalAccount.isEmpty()){
            throw new AccountNotFoundException("Invalid Account Number");
        }
        List<Transaction> transactions = transactionRepository.getTransactionsByAccountNo(accountNo);
        return transactions.stream().map(TransactionMapper::toDTO).collect(Collectors.toList());
    }

    @Override
    public List<TransactionDTO> getTransactionsBetweenDates(long accountNo, LocalDate startDate, LocalDate endDate) {
//        List<Transaction> transactionsByAccount = transactionRepository.getTransactionsByAccountNo(accountNo);
        Optional<Account> optionalAccount = accountRepository.findById(accountNo);
        if(optionalAccount.isEmpty()){
            throw new AccountNotFoundException("Invalid Account Number");
        }
        Account account = optionalAccount.get();
        LocalDate accountCreationDate = account.getCreatedAt();
        if(startDate.isBefore(accountCreationDate)){
            throw new IllegalArgumentException("Start Date cannot be before Account creation date");
        }
        if(startDate.isAfter(endDate)){
            throw new IllegalArgumentException("Start Date cannot be after end Date");
        }
        if(endDate.isAfter(LocalDate.now())){
            throw new IllegalArgumentException("End Date cannot be in the future");
        }
        if(endDate.isBefore(startDate)){
            throw new IllegalArgumentException("End Date cannot be before start date");
        }
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23,59,59);
        List<Transaction> transactions = transactionRepository.getTransactionsBetweenDates(accountNo,startDateTime,endDateTime);
        return transactions.stream().map(TransactionMapper::toDTO).collect(Collectors.toList());
    }


}
