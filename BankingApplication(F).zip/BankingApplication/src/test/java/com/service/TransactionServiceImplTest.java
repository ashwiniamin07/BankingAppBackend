//package com.service;
//
//
//import com.bean.Account;
//import com.bean.Transaction;
//import com.repository.AccountRepository;
//import com.repository.TransactionRepository;
//import org.junit.Test;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Optional;
//
//
//public class TransactionServiceImplTest {
//
//    @InjectMocks
//    private TransactionServiceImpl transactionService;
//
//    @Mock
//    private TransactionRepository transactionRepository;
//
//    @Mock
//    private AccountRepository accountRepository;
//
//    @BeforeEach
//    void setUp(){
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testInjection(){
//        Assertions.assertNotNull(accountRepository,"accountRepository is null");
//        Assertions.assertNotNull(transactionService,"transactionService is null");
//    }
//    @Test
//    public void testDepositSuccess(){
//        Long accountNo = 1L;
//        Double amount = 100.0;
//        Account account = new Account();
//        account.setAccountNo(accountNo);
//        account.setBalance(500.0);
//        account.setIsFrozen(false);
//
//        Mockito.when(accountRepository.findById(accountNo)).thenReturn(Optional.of(account));
//        String result = transactionService.deposit(accountNo,amount);
//        Assertions.assertEquals("Deposit Successful",result);
//        Mockito.verify(accountRepository).save(account);
//        Mockito.verify(transactionRepository).save(Mockito.any(Transaction.class));
//
//    }
//
//
//
//}
